#!/bin/bash

# Energy Ingestion Engine - Integration Test Script
# This script demonstrates API usage and tests the system end-to-end

set -e

BASE_URL="http://localhost:3000"
METER_ID="550e8400-e29b-41d4-a716-446655440001"
VEHICLE_ID="660e8400-e29b-41d4-a716-446655440001"

echo "🚀 Energy Ingestion Engine - Integration Test"
echo "=============================================="

# Color codes
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Utility function to pretty-print JSON
pretty_json() {
  echo "$1" | jq '.' 2>/dev/null || echo "$1"
}

# Test 1: Health Check
echo -e "\n${BLUE}[TEST 1] Health Check${NC}"
RESPONSE=$(curl -s -X POST "$BASE_URL/v1/ingest/health")
echo "Response: $RESPONSE"

# Test 2: Single Meter Ingestion
echo -e "\n${BLUE}[TEST 2] Ingest Single Meter Reading${NC}"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

METER_PAYLOAD=$(cat <<EOF
{
  "meterId": "$METER_ID",
  "kwhConsumedAc": 45.32,
  "voltage": 230.5,
  "timestamp": "$TIMESTAMP"
}
EOF
)

echo "Payload:"
pretty_json "$METER_PAYLOAD"

RESPONSE=$(curl -s -X POST "$BASE_URL/v1/ingest/meter" \
  -H "Content-Type: application/json" \
  -d "$METER_PAYLOAD")
echo "Response:"
pretty_json "$RESPONSE"

# Test 3: Batch Meter Ingestion
echo -e "\n${BLUE}[TEST 3] Batch Meter Ingestion (10 readings)${NC}"

BATCH_PAYLOAD="["
for i in {1..10}; do
  METER_ID_TEMP="550e8400-e29b-41d4-a716-$(printf '44665544000%d' $i)"
  KWH=$(echo "40 + $RANDOM / 100" | bc)
  
  BATCH_PAYLOAD+=$(cat <<EOF
{
  "meterId": "$METER_ID_TEMP",
  "kwhConsumedAc": $KWH,
  "voltage": 230.$((RANDOM % 10)),
  "timestamp": "$TIMESTAMP"
}
EOF
)
  [ $i -lt 10 ] && BATCH_PAYLOAD+=","
done
BATCH_PAYLOAD+="]"

echo "Sending batch of 10 meter readings..."
RESPONSE=$(curl -s -X POST "$BASE_URL/v1/ingest/meter/batch" \
  -H "Content-Type: application/json" \
  -d "$BATCH_PAYLOAD")
echo "Response:"
pretty_json "$RESPONSE"

# Test 4: Single Vehicle Ingestion
echo -e "\n${BLUE}[TEST 4] Ingest Single Vehicle Reading${NC}"

VEHICLE_PAYLOAD=$(cat <<EOF
{
  "vehicleId": "$VEHICLE_ID",
  "soc": 85.5,
  "kwhDeliveredDc": 42.10,
  "batteryTemp": 28.3,
  "timestamp": "$TIMESTAMP"
}
EOF
)

echo "Payload:"
pretty_json "$VEHICLE_PAYLOAD"

RESPONSE=$(curl -s -X POST "$BASE_URL/v1/ingest/vehicle" \
  -H "Content-Type: application/json" \
  -d "$VEHICLE_PAYLOAD")
echo "Response:"
pretty_json "$RESPONSE"

# Test 5: Batch Vehicle Ingestion
echo -e "\n${BLUE}[TEST 5] Batch Vehicle Ingestion (10 readings)${NC}"

BATCH_PAYLOAD="["
for i in {1..10}; do
  VEHICLE_ID_TEMP="660e8400-e29b-41d4-a716-$(printf '44665544000%d' $i)"
  SOC=$(echo "20 + $RANDOM / 1000" | bc)
  
  BATCH_PAYLOAD+=$(cat <<EOF
{
  "vehicleId": "$VEHICLE_ID_TEMP",
  "soc": $SOC,
  "kwhDeliveredDc": $((30 + RANDOM % 20)).$((RANDOM % 100)),
  "batteryTemp": $((20 + RANDOM % 20)).$((RANDOM % 10)),
  "timestamp": "$TIMESTAMP"
}
EOF
)
  [ $i -lt 10 ] && BATCH_PAYLOAD+=","
done
BATCH_PAYLOAD+="]"

echo "Sending batch of 10 vehicle readings..."
RESPONSE=$(curl -s -X POST "$BASE_URL/v1/ingest/vehicle/batch" \
  -H "Content-Type: application/json" \
  -d "$BATCH_PAYLOAD")
echo "Response:"
pretty_json "$RESPONSE"

# Test 6: Multiple Readings Over Time
echo -e "\n${BLUE}[TEST 6] Simulate 24-Hour Data (100 readings per device)${NC}"
echo "Generating 100 meter + vehicle readings over 24 hours..."

for hour in {0..23}; do
  for minute in {0..2..6}; do
    TEST_TIME=$(date -u -d "$hour hours $minute minutes ago" +"%Y-%m-%dT%H:%M:%SZ")
    
    # Meter reading
    curl -s -X POST "$BASE_URL/v1/ingest/meter" \
      -H "Content-Type: application/json" \
      -d "{
        \"meterId\": \"550e8400-e29b-41d4-a716-446655440001\",
        \"kwhConsumedAc\": $((40 + RANDOM % 20)).$((RANDOM % 100)),
        \"voltage\": 230.$((RANDOM % 10)),
        \"timestamp\": \"$TEST_TIME\"
      }" > /dev/null 2>&1
    
    # Vehicle reading
    curl -s -X POST "$BASE_URL/v1/ingest/vehicle" \
      -H "Content-Type: application/json" \
      -d "{
        \"vehicleId\": \"660e8400-e29b-41d4-a716-446655440001\",
        \"soc\": $((20 + RANDOM / 1000)).$((RANDOM % 100)),
        \"kwhDeliveredDc\": $((35 + RANDOM % 15)).$((RANDOM % 100)),
        \"batteryTemp\": $((22 + RANDOM % 15)).$((RANDOM % 10)),
        \"timestamp\": \"$TEST_TIME\"
      }" > /dev/null 2>&1
  done
  echo "  ✓ Hour $hour complete"
done

echo -e "${GREEN}✓ 24-hour data loaded${NC}"

# Test 7: Analytics Endpoint
echo -e "\n${BLUE}[TEST 7] Get Performance Analytics (24-hour)${NC}"

RESPONSE=$(curl -s "$BASE_URL/v1/analytics/performance/660e8400-e29b-41d4-a716-446655440001")
echo "Response:"
pretty_json "$RESPONSE"

# Test 8: Analytics with Different Time Window
echo -e "\n${BLUE}[TEST 8] Get Performance Analytics (72-hour)${NC}"

RESPONSE=$(curl -s "$BASE_URL/v1/analytics/performance/660e8400-e29b-41d4-a716-446655440001?hoursBack=72")
echo "Response:"
pretty_json "$RESPONSE"

echo -e "\n${GREEN}✓ All tests completed successfully!${NC}"
echo -e "${YELLOW}Note: Check the analytics response for efficiency calculations${NC}"
