-- Energy Ingestion Engine Database Initialization
-- PostgreSQL initialization script for Docker

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Smart Meter Live Table (Hot Path - Operational Store)
CREATE TABLE IF NOT EXISTS smart_meter_live (
  meter_id UUID PRIMARY KEY,
  kwh_consumed_ac NUMERIC(10, 2) NOT NULL,
  voltage NUMERIC(5, 2) NOT NULL,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  last_updated TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_meter_live_id ON smart_meter_live(meter_id);

-- Smart Meter History Table (Cold Path - Audit Trail)
CREATE TABLE IF NOT EXISTS smart_meter_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meter_id UUID NOT NULL,
  kwh_consumed_ac NUMERIC(10, 2) NOT NULL,
  voltage NUMERIC(5, 2) NOT NULL,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_meter_history_id_timestamp ON smart_meter_history(meter_id, timestamp);
CREATE INDEX idx_meter_history_timestamp ON smart_meter_history(timestamp);

-- Vehicle Live Table (Hot Path - Operational Store)
CREATE TABLE IF NOT EXISTS vehicle_live (
  vehicle_id UUID PRIMARY KEY,
  soc NUMERIC(5, 2) NOT NULL,
  kwh_delivered_dc NUMERIC(10, 2) NOT NULL,
  battery_temp NUMERIC(5, 2) NOT NULL,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  last_updated TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vehicle_live_id ON vehicle_live(vehicle_id);

-- Vehicle History Table (Cold Path - Audit Trail)
CREATE TABLE IF NOT EXISTS vehicle_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL,
  soc NUMERIC(5, 2) NOT NULL,
  kwh_delivered_dc NUMERIC(10, 2) NOT NULL,
  battery_temp NUMERIC(5, 2) NOT NULL,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vehicle_history_id_timestamp ON vehicle_history(vehicle_id, timestamp);
CREATE INDEX idx_vehicle_history_timestamp ON vehicle_history(timestamp);

-- Energy Correlation Table
CREATE TABLE IF NOT EXISTS energy_correlation (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meter_id UUID NOT NULL,
  vehicle_id UUID NOT NULL,
  kwh_consumed_ac NUMERIC(10, 2) NOT NULL,
  kwh_delivered_dc NUMERIC(10, 2) NOT NULL,
  efficiency_ratio NUMERIC(5, 2) NOT NULL,
  is_anomalous BOOLEAN DEFAULT FALSE,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_correlation_meter_vehicle_ts ON energy_correlation(meter_id, vehicle_id, timestamp);
CREATE INDEX idx_correlation_timestamp ON energy_correlation(timestamp);

-- Partitioning Strategy for History Tables (for production at scale)
-- Historical data can be partitioned by month for optimal performance
-- This example shows how to partition vehicle_history:
-- ALTER TABLE vehicle_history
-- ADD PARTITION BY RANGE (YEAR(timestamp), MONTH(timestamp));

-- Grant permissions (optional, for specific users)
-- GRANT SELECT, INSERT ON smart_meter_live TO app_user;
-- GRANT SELECT, INSERT ON smart_meter_history TO app_user;
-- GRANT SELECT, INSERT ON vehicle_live TO app_user;
-- GRANT SELECT, INSERT ON vehicle_history TO app_user;

-- Summary: Database optimized for:
-- 1. Hot path (live tables): Fast UPSERT for current state access
-- 2. Cold path (history tables): Fast INSERT for audit trail with strong indexing
-- 3. Analytics: Indexed queries on (device_id, timestamp) for fast aggregations
-- 4. Scale: Ready for billions of records with attention to index selectivity
