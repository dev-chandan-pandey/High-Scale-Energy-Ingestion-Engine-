# Deployment Guide

## Pre-Deployment Checklist

### 1. Environment Configuration
```bash
# Copy and customize environment variables
cp .env.example .env.production

# Required variables for production:
DB_HOST=your-postgres-host
DB_PORT=5432
DB_USERNAME=prod_user
DB_PASSWORD=secure_password_here
DB_NAME=energy_ingestion_prod
NODE_ENV=production
PORT=3000
DB_LOGGING=false              # Disable for performance
ENABLE_METRICS=true
```

### 2. Database Setup

#### Option A: Docker (Recommended for Small-Medium Scale)
```bash
docker-compose up -d
```

#### Option B: Managed PostgreSQL (AWS RDS, Azure, GCP)
```bash
# 1. Create DB instance with:
#    - PostgreSQL 16+
#    - 100+ GB storage (initial, scale as needed)
#    - Multi-AZ enabled for HA
#    - Automated backups (daily minimum)

# 2. Initialize schema:
psql postgresql://user:pass@host:5432/db < init.sql

# 3. Configure connection pooling:
# Use PgBouncer or AWS RDS connection pool (5-50 connections)
```

### 3. Application Deployment

#### Kubernetes (Recommended for High Scale)
```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: energy-ingestion
spec:
  replicas: 3
  selector:
    matchLabels:
      app: energy-ingestion
  template:
    metadata:
      labels:
        app: energy-ingestion
    spec:
      containers:
      - name: app
        image: your-registry/energy-ingestion:latest
        ports:
        - containerPort: 3000
        env:
        - name: DB_HOST
          valueFrom:
            configMapKeyRef:
              name: db-config
              key: host
        - name: DB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: password
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /v1/ingest/health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /v1/ingest/health
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: energy-ingestion-service
spec:
  type: LoadBalancer
  ports:
  - protocol: TCP
    port: 80
    targetPort: 3000
  selector:
    app: energy-ingestion
```

#### AWS ECS
```bash
# 1. Push image to ECR
aws ecr get-login-password | docker login --username AWS --password-stdin <account>.dkr.ecr.<region>.amazonaws.com
docker tag energy-ingestion:latest <account>.dkr.ecr.<region>.amazonaws.com/energy-ingestion:latest
docker push <account>.dkr.ecr.<region>.amazonaws.com/energy-ingestion:latest

# 2. Create ECS cluster and task definition
# 3. Run service with desired count = 3-5 (for 10k devices)
```

### 4. Monitoring & Logging

#### CloudWatch/Datadog/New Relic Setup
```javascript
// src/main.ts - Add monitoring
import * as newrelic from 'newrelic';
// Or equivalent for your logging provider

const app = await NestFactory.create(AppModule);
// Add middleware for metrics
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`[METRIC] ${req.method} ${req.url} ${res.statusCode} ${duration}ms`);
  });
  next();
});
```

#### Key Metrics to Monitor
```
Ingestion:
  - POST /v1/ingest/meter - target: <50ms p99
  - POST /v1/ingest/vehicle - target: <50ms p99
  - Records per second - target: >1000 rps

Analytics:
  - GET /v1/analytics/performance/:vehicleId - target: <100ms p99
  - Query database time - target: <50ms

Database:
  - Connection pool utilization
  - Slow query log (>5s queries)
  - Replication lag (if using replicas)
  - IOPS usage

Application:
  - Memory usage - target: <1GB per instance
  - CPU usage - target: <60%
  - Error rate - target: <0.1%
```

### 5. Database Tuning for Production

```sql
-- Connection pooling
-- Use PgBouncer in transaction mode
-- Min: 10 connections
-- Max: 50 connections for 10k devices

-- Query optimization
ANALYZE smart_meter_history;
ANALYZE vehicle_history;

-- Monitor slow queries
ALTER SYSTEM SET log_min_duration_statement = 5000;  -- Log queries >5s

-- Vacuum strategy (auto-vacuum)
ALTER TABLE smart_meter_history SET (autovacuum_vacuum_scale_factor = 0.01);
ALTER TABLE vehicle_history SET (autovacuum_vacuum_scale_factor = 0.01);

-- Partitioning (when exceeding 1GB per table)
-- Already included in init.sql comments
```

### 6. Backup & Disaster Recovery

#### Daily Backups
```bash
# Using pg_dump (recommended for <100GB)
PGPASSWORD=$DB_PASSWORD pg_dump -h $DB_HOST -U $DB_USERNAME $DB_NAME | gzip > backup-$(date +%Y%m%d).sql.gz

# Upload to S3
aws s3 cp backup-$(date +%Y%m%d).sql.gz s3://your-backup-bucket/

# Archive old data
```

#### Restore Procedure
```bash
gunzip < backup-20240208.sql.gz | psql postgresql://user:pass@host:5432/db
```

### 7. Load Testing Before Production

```bash
# Using Apache Bench
ab -n 10000 -c 100 -p meter.json -T application/json http://localhost:3000/v1/ingest/meter

# Expected results for 2-core instance:
# - 500+ rps for meter ingestion
# - 1000+ rps for meter batch ingestion (100 items)
# - <100ms p99 for analytics queries
```

### 8. Production Security

```
API Authentication:
  - Implement API key validation
  - Use JWT tokens for device authentication
  - Rate limiting: 10k rps per IP

Database Security:
  - Encrypted passwords in Secrets Manager
  - SSL/TLS for database connections
  - Restrict network access (VPC security groups)
  
Application Security:
  - Enable HTTPS only
  - CORS configuration
  - Input validation (already in DTOs)
  - Helmet.js middleware for response headers
```

Add to main.ts:
```typescript
import helmet from '@nestjs/helmet';

app.use(helmet());
```

### 9. Scaling Strategy

#### Phase 1: 10k devices (Current Build)
- 3-5 replicas of application
- Single PostgreSQL instance with r6g.xlarge specs
- Target: 14.4M records daily

#### Phase 2: 50k devices
- 10-15 replicas
- PostgreSQL r6g.2xlarge with read replicas
- Implement table partitioning by month
- Add Redis caching layer for current state

#### Phase 3: 100k+ devices
- Distributed architecture with regional deployments
- TimescaleDB for time-series optimization
- Kafka for async ingestion buffering
- Multi-region PostgreSQL replication

---

## Post-Deployment

1. **Health Checks**
   ```bash
   curl http://your-domain/v1/ingest/health
   ```

2. **Smoke Tests**
   - Run test-api.sh against production
   - Verify metrics in monitoring dashboard

3. **Performance Validation**
   - Monitor ingestion latency (target: <50ms)
   - Monitor analytics latency (target: <100ms)
   - Check database CPU/memory

4. **Capacity Planning**
   - Document baseline performance
   - Set up alerts for anomalies
   - Plan for 2x growth

---

## Troubleshooting

### High Memory Usage
```bash
# Check Node.js heap
node --max-old-space-size=2048 dist/main.js

# Profile memory usage
# node --inspect dist/main.js
# Then use Chrome DevTools
```

### Slow Analytics Queries
```sql
-- Explain slow query
EXPLAIN ANALYZE
SELECT * FROM vehicle_history
WHERE vehicle_id = 'xxx' AND timestamp >= '2024-01-01';

-- Check index usage
SELECT * FROM pg_stat_user_indexes;

-- Rebuild index if needed
REINDEX INDEX idx_vehicle_history_id_timestamp;
```

### Database Connection Exhaustion
```bash
# Check current connections
psql -c "SELECT count(*) FROM pg_stat_activity;"

# Increase max connections (restart required)
ALTER SYSTEM SET max_connections = 500;
```

---

**Maintained by:** Backend Engineering Team  
**Last Updated:** February 8, 2026
