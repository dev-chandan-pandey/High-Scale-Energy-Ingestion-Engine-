# API Documentation

## Base URL

```
Development:  http://localhost:3000
Production:   https://api.energy-platform.com
```

## Authentication

Currently, the API is open (no authentication). For production deployment, implement:
- API Key validation
- JWT bearer tokens
- OAuth 2.0 for client applications

## Response Format

### Success Response (2xx)

```json
{
  "status": "accepted",
  "data": {}
}
```

### Error Response (4xx, 5xx)

```json
{
  "statusCode": 400,
  "message": "Invalid meter ID format",
  "error": "Bad Request"
}
```

---

## Endpoints

### 1. POST /v1/ingest/meter

**Description:** Ingest a single smart meter AC consumption reading

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| meterId | string (UUID) | Yes | Unique meter identifier |
| kwhConsumedAc | number | Yes | AC power consumed (kWh), ≥ 0 |
| voltage | number | Yes | Grid voltage (V), ≥ 0 |
| timestamp | string (ISO8601) | Yes | Reading timestamp (UTC) |

**Example Request:**

```bash
curl -X POST http://localhost:3000/v1/ingest/meter \
  -H "Content-Type: application/json" \
  -d '{
    "meterId": "550e8400-e29b-41d4-a716-446655440000",
    "kwhConsumedAc": 45.32,
    "voltage": 230.5,
    "timestamp": "2024-02-08T10:30:00Z"
  }'
```

**Response:** `202 Accepted`

```json
{
  "status": "accepted"
}
```

**Error Responses:**

```json
// 400 - Invalid UUID format
{
  "statusCode": 400,
  "message": "meterId must be a UUID",
  "error": "Bad Request"
}

// 400 - Missing required field
{
  "statusCode": 400,
  "message": "kwhConsumedAc must be >= 0",
  "error": "Bad Request"
}

// 500 - Database error
{
  "statusCode": 500,
  "message": "Failed to ingest meter reading",
  "error": "Internal Server Error"
}
```

**Performance:**

- Typical latency: 30-50ms
- p99 latency: <100ms
- Expected throughput: >500 rps

---

### 2. POST /v1/ingest/meter/batch

**Description:** Ingest multiple meter readings in a single request (optimized)

**Request Body:** Array of meter reading objects

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| [...] | array | Yes | Array of meter reading objects (see endpoint 1) |

**Constraints:**
- Maximum 1000 readings per batch
- Recommended batch size: 100-500 for optimal performance

**Example Request:**

```bash
curl -X POST http://localhost:3000/v1/ingest/meter/batch \
  -H "Content-Type: application/json" \
  -d '[
    {
      "meterId": "550e8400-e29b-41d4-a716-446655440001",
      "kwhConsumedAc": 45.32,
      "voltage": 230.5,
      "timestamp": "2024-02-08T10:30:00Z"
    },
    {
      "meterId": "550e8400-e29b-41d4-a716-446655440002",
      "kwhConsumedAc": 38.15,
      "voltage": 231.2,
      "timestamp": "2024-02-08T10:30:00Z"
    }
  ]'
```

**Response:** `202 Accepted`

```json
{
  "status": "accepted",
  "count": 2
}
```

**Performance:**

- 100 items: 80-120ms
- 500 items: 200-300ms
- 1000 items: 300-500ms
- Throughput: >3000 rps (vs. 500 rps single)

---

### 3. POST /v1/ingest/vehicle

**Description:** Ingest a single EV/vehicle DC delivery and battery reading

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| vehicleId | string (UUID) | Yes | Unique vehicle identifier |
| soc | number | Yes | State of Charge (%), range: [0, 100] |
| kwhDeliveredDc | number | Yes | DC power delivered to battery (kWh), ≥ 0 |
| batteryTemp | number | Yes | Battery temperature (°C) |
| timestamp | string (ISO8601) | Yes | Reading timestamp (UTC) |

**Example Request:**

```bash
curl -X POST http://localhost:3000/v1/ingest/vehicle \
  -H "Content-Type: application/json" \
  -d '{
    "vehicleId": "660e8400-e29b-41d4-a716-446655440000",
    "soc": 85.5,
    "kwhDeliveredDc": 42.10,
    "batteryTemp": 28.3,
    "timestamp": "2024-02-08T10:30:00Z"
  }'
```

**Response:** `202 Accepted`

```json
{
  "status": "accepted"
}
```

**Error Responses:**

```json
// 400 - SoC out of range
{
  "statusCode": 400,
  "message": "soc must be between 0 and 100",
  "error": "Bad Request"
}

// 400 - Invalid timestamp format
{
  "statusCode": 400,
  "message": "timestamp must be a valid ISO8601 string",
  "error": "Bad Request"
}
```

**Performance:**

- Typical latency: 30-50ms
- p99 latency: <100ms
- Expected throughput: >500 rps

---

### 4. POST /v1/ingest/vehicle/batch

**Description:** Ingest multiple vehicle readings in a single request (optimized)

**Request Body:** Array of vehicle reading objects

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| [...] | array | Yes | Array of vehicle reading objects (see endpoint 3) |

**Constraints:**
- Maximum 1000 readings per batch
- Recommended batch size: 100-500 for optimal performance

**Example Request:**

```bash
curl -X POST http://localhost:3000/v1/ingest/vehicle/batch \
  -H "Content-Type: application/json" \
  -d '[
    {
      "vehicleId": "660e8400-e29b-41d4-a716-446655440001",
      "soc": 85.5,
      "kwhDeliveredDc": 42.10,
      "batteryTemp": 28.3,
      "timestamp": "2024-02-08T10:30:00Z"
    },
    {
      "vehicleId": "660e8400-e29b-41d4-a716-446655440002",
      "soc": 92.3,
      "kwhDeliveredDc": 45.05,
      "batteryTemp": 26.1,
      "timestamp": "2024-02-08T10:30:00Z"
    }
  ]'
```

**Response:** `202 Accepted`

```json
{
  "status": "accepted",
  "count": 2
}
```

**Performance:**

- 100 items: 80-120ms
- 500 items: 200-300ms
- 1000 items: 300-500ms
- Throughput: >3000 rps (vs. 500 rps single)

---

### 5. GET /v1/analytics/performance/:vehicleId

**Description:** Get 24-hour (or custom window) performance summary with efficiency analysis

**Path Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| vehicleId | string (UUID) | Yes | Vehicle identifier |

**Query Parameters:**

| Parameter | Type | Default | Range | Description |
|-----------|------|---------|-------|-------------|
| hoursBack | integer | 24 | [1, 720] | Hours of history to analyze (max 30 days) |

**Example Requests:**

```bash
# 24-hour performance (default)
curl http://localhost:3000/v1/analytics/performance/660e8400-e29b-41d4-a716-446655440000

# 72-hour performance
curl http://localhost:3000/v1/analytics/performance/660e8400-e29b-41d4-a716-446655440000?hoursBack=72

# 7-day performance
curl http://localhost:3000/v1/analytics/performance/660e8400-e29b-41d4-a716-446655440000?hoursBack=168
```

**Response:** `200 OK`

```json
{
  "vehicleId": "660e8400-e29b-41d4-a716-446655440000",
  "period": {
    "startTime": "2024-02-07T10:30:00Z",
    "endTime": "2024-02-08T10:30:00Z"
  },
  "energyMetrics": {
    "totalAcConsumed": 1024.50,
    "totalDcDelivered": 892.30,
    "efficiencyRatio": 0.871,
    "powerlossPercentage": 12.9
  },
  "battery": {
    "averageTemperature": 27.5,
    "minTemperature": 22.1,
    "maxTemperature": 35.8,
    "startSoc": 20.0,
    "endSoc": 95.5
  },
  "anomalies": {
    "lowEfficiencyReadings": 2,
    "suspectedFaults": true
  },
  "readingCount": 1440
}
```

**Field Descriptions:**

| Field | Type | Description |
|-------|------|-------------|
| vehicleId | string | The queried vehicle ID |
| period.startTime | string | Analysis start time (ISO8601) |
| period.endTime | string | Analysis end time (ISO8601) |
| totalAcConsumed | number | Total AC power from grid (kWh) |
| totalDcDelivered | number | Total DC power to battery (kWh) |
| efficiencyRatio | number | Ratio of DC/AC (0.0-1.0) |
| powerlossPercentage | number | Power loss percentage (typically 12-15%) |
| averageTemperature | number | Mean battery temperature (°C) |
| minTemperature | number | Lowest battery temperature (°C) |
| maxTemperature | number | Highest battery temperature (°C) |
| startSoc | number | Battery % at window start |
| endSoc | number | Battery % at window end |
| lowEfficiencyReadings | integer | Count of readings below 85% efficiency |
| suspectedFaults | boolean | true if any anomalies detected |
| readingCount | integer | Number of readings analyzed |

**Error Responses:**

```json
// 400 - Invalid hoursBack parameter
{
  "statusCode": 400,
  "message": "hoursBack must be between 1 and 720",
  "error": "Bad Request"
}

// 404 - No data found
// Returns 200 with empty metrics if vehicle has no readings
{
  "vehicleId": "...",
  "period": {...},
  "energyMetrics": {
    "totalAcConsumed": 0,
    "totalDcDelivered": 0,
    "efficiencyRatio": 0,
    "powerlossPercentage": 0
  },
  "readingCount": 0
}
```

**Performance:**

- Typical latency: 50-100ms
- p99 latency: <150ms
- No database table scans (uses indexes)
- Scales linearly with time window (1440 rows per 24hr)

**Interpretation Guide:**

| Efficiency | Status | Action |
|-----------|--------|--------|
| ≥ 0.90 | Excellent | No action needed |
| 0.85 - 0.89 | Good | Monitor |
| 0.80 - 0.84 | Degraded | Investigate charger |
| < 0.80 | Critical | Probable equipment failure |

---

### 6. POST /v1/ingest/health

**Description:** Health check endpoint (returns 200 OK if service is healthy)

**Example Request:**

```bash
curl -X POST http://localhost:3000/v1/ingest/health
```

**Response:** `200 OK`

```json
{
  "status": "ok"
}
```

**Use Case:** Docker health checks, Kubernetes liveness probes, load balancer checks

---

## Rate Limiting

**Recommended (Production):**
- Per IP: 10,000 requests/minute
- Per API Key: 100,000 requests/minute
- Batch size: Max 1,000 items per request

**Implement using:**
```typescript
// In main.ts
import { ThrottlerModule } from '@nestjs/throttler';

ThrottlerModule.forRoot([
  {
    ttl: 60000,  // 1 minute
    limit: 10000, // 10k requests
  },
])
```

---

## Error Codes Reference

| Code | Message | Cause | Solution |
|------|---------|-------|----------|
| 202 | Accepted | Valid request | Normal response |
| 400 | Bad Request | Invalid input | Check request body format/values |
| 400 | Invalid UUID | Malformed UUID | Use valid UUID v4 format |
| 400 | SoC out of range | SoC < 0 or > 100 | Provide value between 0-100 |
| 400 | Invalid timestamp | Wrong ISO8601 format | Use: YYYY-MM-DDTHH:MM:SSZ |
| 500 | Internal Server Error | DB connection failed | Check PostgreSQL is running |
| 503 | Service Unavailable | DB unavailable | Wait and retry |

---

## Webhook/Notification Support (Future)

Planned for v2.0:
- Real-time alerts for efficiency < 85%
- Scheduled daily performance summaries
- WebSocket support for streaming ingestion

---

## SDK/Client Libraries (Future)

Planned:
- JavaScript/TypeScript SDK
- Python client library
- Go client library

---

## Deprecation Policy

Breaking changes will:
1. Be announced 30 days in advance
2. Provide migration guide
3. Maintain v1 endpoints for 6 months
4. Use semantic versioning (v1, v2, etc.)

---

## Support

- Issues: [GitHub Issues](https://github.com/dev-chandan-pandey/High-Scale-Energy-Ingestion-Engine-/issues)
- Documentation: See [README.md](./README.md)
- Deployment: See [DEPLOYMENT.md](./DEPLOYMENT.md)

---

**Last Updated:** February 8, 2026  
**API Version:** 1.0.0
