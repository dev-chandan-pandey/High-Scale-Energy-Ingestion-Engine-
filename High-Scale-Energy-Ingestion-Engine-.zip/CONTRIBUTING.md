# Contributing Guide

## Development Setup

### Prerequisites
- Node.js 20+
- PostgreSQL 16+
- Docker & Docker Compose (optional, for local DB)

### Getting Started

```bash
# 1. Clone repository
git clone https://github.com/dev-chandan-pandey/High-Scale-Energy-Ingestion-Engine-.git
cd High-Scale-Energy-Ingestion-Engine-

# 2. Install dependencies
npm install

# 3. Set up local environment
cp .env.example .env.development
# Edit .env.development with your PG connection

# 4. Start development server
npm run dev

# Server runs on http://localhost:3000
```

### Or Use Docker for Local Development

```bash
# Start PostgreSQL only (not the app)
docker-compose up postgres pgadmin

# Then run app locally
npm install
npm run dev
```

## Code Structure

```
src/
├── entities/        # TypeORM entity definitions
├── dto/            # Data Transfer Objects (input validation)
├── services/       # Business logic & data access
├── controllers/    # HTTP route handlers
├── config/         # Configuration files
├── app.module.ts   # NestJS DI container
└── main.ts         # Entry point
```

## Key Architectural Constraints

### 1. Always Use Indexed Queries

When querying history tables, ensure you're using indexed columns:

```typescript
// ❌ BAD - Full table scan
const readings = await this.repo.find();

// ✅ GOOD - Uses index
const readings = await this.repo
  .createQueryBuilder('r')
  .where('r.vehicleId = :vehicleId', { vehicleId })
  .andWhere('r.timestamp >= :start AND r.timestamp <= :end', { start, end })
  .getMany();
```

### 2. Separate INSERT (Cold) from UPSERT (Hot)

Different tables, different strategies:

```typescript
// Cold path: History table - INSERT only
await this.historyRepo.insert(record);

// Hot path: Live table - UPSERT only
await this.liveRepo.upsert(record, ['deviceId']);
```

### 3. Batch Operations When Possible

```typescript
// ❌ SLOW - N individual inserts
for (const dto of dtos) {
  await repo.insert(dto);
}

// ✅ FAST - Single batch insert
await repo.insert(dtos);
```

### 4. Aggregate in App, Not in Database

For 24-hour summaries, load indexed rows and compute in Node.js:

```typescript
// ❌ BAD - Slow GROUP BY on billions of rows
const results = await db.query(`
  SELECT vehicle_id, AVG(battery_temp), SUM(kwh) 
  FROM vehicle_history 
  GROUP BY vehicle_id
`);

// ✅ GOOD - Fetch with index, aggregate in app
const readings = await this.vehicleHistoryRepo
  .createQueryBuilder('vh')
  .where('vh.vehicleId = :vehicleId', { vehicleId })
  .andWhere('vh.timestamp BETWEEN :start AND :end', { start, end })
  .getMany();

const avgTemp = readings.reduce((sum, r) => sum + r.batteryTemp, 0) / readings.length;
```

## Development Workflow

### Adding a New Feature

#### 1. Create Entity (if needed)
```typescript
// src/entities/my-entity.entity.ts
@Entity('my_table')
@Index('idx_device_timestamp', ['deviceId', 'timestamp'])
export class MyEntity {
  // ...
}
```

#### 2. Create DTO for Validation
```typescript
// src/dto/my-input.dto.ts
export class MyInputDto {
  @IsString()
  deviceId: string;
  // ...
}
```

#### 3. Create Service Logic
```typescript
// src/services/my.service.ts
@Injectable()
export class MyService {
  constructor(
    @InjectRepository(MyEntity)
    private repo: Repository<MyEntity>,
  ) {}

  async process(dto: MyInputDto): Promise<void> {
    // Use indexed queries
    // Separate hot/cold paths
  }
}
```

#### 4. Create Controller Endpoint
```typescript
// src/controllers/my.controller.ts
@Controller('v1/my')
export class MyController {
  constructor(private readonly myService: MyService) {}

  @Post()
  async create(@Body() dto: MyInputDto) {
    return this.myService.process(dto);
  }
}
```

#### 5. Register in AppModule
```typescript
@Module({
  imports: [TypeOrmModule.forFeature([MyEntity])],
  controllers: [MyController],
  providers: [MyService],
})
export class AppModule {}
```

### Testing

#### Unit Tests Example
```typescript
// src/services/my.service.spec.ts
describe('MyService', () => {
  let service: MyService;
  let repo: Repository<MyEntity>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MyService,
        {
          provide: getRepositoryToken(MyEntity),
          useValue: {
            insert: jest.fn(),
            upsert: jest.fn(),
            findOne: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<MyService>(MyService);
    repo = module.get<Repository<MyEntity>>(getRepositoryToken(MyEntity));
  });

  it('should insert into history', async () => {
    const dto = { /* ... */ };
    await service.process(dto);
    expect(repo.insert).toHaveBeenCalled();
  });
});
```

Run tests:
```bash
npm test                  # Run once
npm test:watch          # Watch mode
npm test -- --coverage  # With coverage
```

### Performance Testing

Before and after changes, run:
```bash
# Load test ingestion
npm run load-test:ingest

# Load test analytics
npm run load-test:analytics
```

Expected benchmarks:
- Single meter ingest: <50ms
- Batch (100) ingest: <200ms
- 24-hour analytics: <100ms

## Code Quality

### Linting & Formatting

```bash
npm run lint          # Check linting issues
npm run format        # Auto-format code
```

Configuration in `.eslintrc.js` and `.prettierrc`

### TypeScript Standards

- Always use strict mode (already enabled in tsconfig.json)
- Use type annotations for function parameters and returns
- Avoid `any` type - use generics instead
- Use interfaces for data contracts

```typescript
// ❌ BAD
async process(data) {
  return data;
}

// ✅ GOOD
async process(data: ProcessDto): Promise<ResultDto> {
  return { /* typed result */ };
}
```

## Commit Guidelines

### Conventional Commits

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `refactor`: Code restructuring
- `perf`: Performance improvement
- `test`: Test additions
- `docs`: Documentation
- `chore`: Dependencies, config

**Examples:**
```
feat(metrics): Add efficiency anomaly detection

fix(analytics): Use indexed query for 24h summary

perf(ingestion): Optimize batch insert for 1000+ records

docs(schema): Explain hot/cold storage strategy
```

## Pull Request Process

1. **Create Feature Branch**
   ```bash
   git checkout -b feat/my-feature
   ```

2. **Make Changes**
   - Follow code structure guidelines
   - Add tests for new features
   - Update types

3. **Run Quality Checks**
   ```bash
   npm run build      # Compile TypeScript
   npm test           # Run all tests
   npm run lint       # Check code quality
   ```

4. **Commit**
   ```bash
   git add .
   git commit -m "feat(scope): description"
   ```

5. **Push & Create PR**
   ```bash
   git push origin feat/my-feature
   ```

   PR checklist:
   - [ ] TypeScript compiles without errors
   - [ ] All tests pass
   - [ ] Code follows style guidelines
   - [ ] Updated README/docs if needed
   - [ ] No performance regressions

6. **Code Review**
   - Address reviewer comments
   - Maintain indexed query strategy
   - Preserve hot/cold data separation

## Performance Considerations

### When Adding New Queries

**Checklist:**
- [ ] Is there a relevant index?
- [ ] Will it scan <100k rows?
- [ ] Is timestamp in WHERE clause?
- [ ] Should device_id be in WHERE?
- [ ] Could it block other operations?

### When Adding New Tables

**Checklist:**
- [ ] Hot or Cold data?
- [ ] Which columns need indexes?
- [ ] Composite index priorities?
- [ ] Expected daily row count?
- [ ] Partition strategy?

### Monitoring Queries

```sql
-- Identify slow queries
SELECT query, calls, mean_time
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 10;

-- Check index usage
SELECT schemaname, tablename, indexname, idx_scan
FROM pg_stat_user_indexes
ORDER BY idx_scan ASC;

-- Find missing indexes
SELECT schemaname, tablename, attname
FROM pg_stat_user_tables JOIN pg_attribute...
WHERE seq_scan > idx_scan;
```

## Documentation

### Code Comments

```typescript
/**
 * Ingest meter reading with dual persistence
 * 
 * Strategy:
 *  1. INSERT to history (append-only audit trail)
 *  2. UPSERT to live (current state)
 * 
 * @param dto - Meter telemetry data
 * @returns Void (fire-and-forget pattern)
 */
async ingestMeterReading(dto: MeterTelemetryDto): Promise<void> {
  // ...
}
```

### README/Architecture Docs

Update [README.md](./README.md) when:
- Adding new endpoints
- Changing database schema
- Introducing new architectural patterns
- Scaling considerations change

## Common Issues

### "Relations are not found"
```typescript
// ❌ Issue: Entity not registered in AppModule
// ✓ Solution: Add to TypeOrmModule.forFeature([])
```

### "Slow analytics queries"
```sql
-- Check if indexes are being used
EXPLAIN ANALYZE
SELECT * FROM vehicle_history
WHERE vehicle_id = '...' AND timestamp BETWEEN '2024-01-01' AND '2024-01-02';
-- Look for "Index Scan" in plan, not "Seq Scan"
```

### "Connection pool exhausted"
```typescript
// Increase pool size in database.config.ts
// Or use connection pooling middleware (PgBouncer)
```

## Resources

- [NestJS Docs](https://docs.nestjs.com)
- [TypeORM Docs](https://typeorm.io/)
- [PostgreSQL Indexing](https://www.postgresql.org/docs/current/sql-createindex.html)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)

## Questions?

- Check [README.md](./README.md) for architectural overview
- Review [DEPLOYMENT.md](./DEPLOYMENT.md) for production setup
- Check existing code for patterns
- Open an issue with the `question` label

---

**Happy Contributing! 🚀**
